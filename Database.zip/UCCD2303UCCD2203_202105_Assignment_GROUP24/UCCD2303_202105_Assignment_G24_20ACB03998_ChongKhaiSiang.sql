CREATE TABLE BRANCH
(Branch_ID VARCHAR(5) NOT NULL CONSTRAINT BRANCH_pk PRIMARY KEY,
Branch_Name VARCHAR(50) NOT NULL,	
Branch_State VARCHAR(50) NOT NULL,
Branch_Customer_Quantity INT
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B01','WISDOM Book Store Menglembu','Perak','190899'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B02','WISDOM Book Store Simpang Ampat','Selangor','120998'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B03','WISDOM Book Store Ipoh Parade','Perak','70222'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B04','WISDOM Book Store Malcca','Melaka','60888'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B05','WISDOM Book Store Aman Larkin','Johor','40233'
);

CREATE TABLE STAFF
( Staff_ID  VARCHAR(12) NOT NULL CONSTRAINT STAFF_pk PRIMARY KEY ,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT Staff_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID) ,
Staff_Name VARCHAR(50) NOT NULL ,
Staff_IC VARCHAR(12) NOT NULL ,
Staff_Gender VARCHAR(6) NOT NULL,	
Staff_PhoneNo VARCHAR(15) NOT NULL,	
Staff_Address VARCHAR(255),	
Staff_DOB DATE ,
Sales_Performance_UnitCase INT
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '101', 'Andrew Boh Zhuang Wei', '000202085547', 'Male', '018-2342345', '10,Jalan Utar 11,Taman Utar,30500,Ipoh,Perak', (to_date('02/02/2000','dd/mm/yyyy')), 'B01', 650
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '102', 'Chong Khai Siang', '990929086647', 'Male', '018-5675678', '27, Tingkat Kledang7,Taman Kledang,31450,Menglembu,Perak', (to_date('29/09/1999','dd/mm/yyyy')), 'B01', 420
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '103', 'Chung Jun Jie Alvin','010828087747', 'Male', '012-8908901', '95,Jalan Merah 8,Taman Merah, 14100, Simpang Ampat, Selangor', (to_date('28/08/2001','dd/mm/yyyy')), 'B02', 300
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '104', 'Loh Chun Yi', '011201088847', 'Male', '012-1231234' ,'3, Jalan Sungai, Taman Suria, 75000, Malacca, Melaka', (to_date('01/12/2001','dd/mm/yyyy')), 'B04', 900
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '105', 'Wong Jian Yong', '010420089947', 'Male' , '011-4564562', '8, Tingkat Kledang 8,Taman Kledang, 31450, Menglembu,Perak', (to_date('20/04/2001','dd/mm/yyyy')), 'B03', 700
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '109', 'Obama', '990808065547', 'Male', '018-5477123', '12, Jalan Aman Larkin 2, Taman Larkin, 28000 Aman Larkin,Johor', (to_date('08/08/1999','dd/mm/yyyy')), 'B05', 200
);



CREATE TABLE INVENTORY
(Inv_ID VARCHAR(12) NOT NULL CONSTRAINT INVENTORY_pk PRIMARY KEY,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT INVENTORY_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID)  ,
Inv_Quantity INT
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L001' , '2000' , 'B01'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L002' , '2000' , 'B01'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L003' , '3500' , 'B02'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L004' , '2000' , 'B03'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L006' , '2000' , 'B04'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L007' , '1500' , 'B05'
);



CREATE TABLE BOOK
(Book_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_pk PRIMARY KEY,
Inv_ID	 VARCHAR (12) NOT NULL CONSTRAINT BOOK_Inv_ID_fk
REFERENCES  INVENTORY(Inv_ID),
Book_Type VARCHAR(255) NOT NULL,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Price_UnitRM NUMBER
); 
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0010','L006','Adult','Cooking Teaching Categories','"Learn How To Cook Easy"',15
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0190','L001','Adult','Business Categories','"How To Success"',50
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0300','L007','Kids','Comic Categories','"Doraemon"', 15
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0100','L002','Teenager','Novel Categories','”Harry Potter”',30
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B1050', 'L007', 'Young Adult', 'Education Categories', '“Grammar in 30 days”',23 
);
CREATE TABLE SALES
(Sales_ID VARCHAR(12) NOT NULL CONSTRAINT SALES_pk PRIMARY KEY ,
Staff_ID VARCHAR(12) NOT NULL CONSTRAINT SALES_Staff_ID_fk
REFERENCES  Staff(Staff_ID),
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT SALES_Branch_ID_fk REFERENCES  BRANCH(Branch_ID),
Customer_No VARCHAR(12) NOT NULL,
Sales_Amount_UnitRM NUMBER NOT NULL,
Book_Quantity INT NOT NULL,
Sales_Date Date 
);

INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS10000' , (to_date('09/07/2021','dd/mm/yyyy')) , 80 , '101' , 'CC8110' , 6 , 'B01' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS09800' , (to_date('08/07/2021','dd/mm/yyyy')) , 120 , '102' , 'CA1080' , 8, 'B02' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS12400' , (to_date('10/07/2021','dd/mm/yyyy')) , 15 , '104' , 'CC4200' , 1 , 'B04' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS12000' , (to_date('10/07/2021','dd/mm/yyyy')) , 9, '101' , 'CA9496' , 1 , 'B03' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS10999' , (to_date('09/07/2021','dd/mm/yyyy')) , 38 , '109' , 'CB8480' , 2 , 'B05' 
);

CREATE TABLE CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT CUSTOMER_pk PRIMARY KEY,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT Customer_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID)  ,	
Sales_ID VARCHAR(12) NOT NULL ,
Membership_ID VARCHAR(12),
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15)
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CA1080' , 'SS09800' , 'M10190' , 'B02' , 'Jacky Chan' , ' 018-1111222' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CC4200' , 'SS12400' , 'M10189' , 'B04' , 'Muhammad Ali'  , '016-2222555' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CC8110' , 'SS10000' , 'M17890' , 'B01' , 'Lee Zhong Wei' , ' 011-4444555' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CB8480' , 'SS10999' , 'M19200' , 'B05' , 'J.W.W.Birch' , ' 016-9999888'
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CA9496' , 'SS12000' , 'M09980' , 'B03' , 'Farah' , '014-3333222'
);

CREATE TABLE MEMBERSHIP 
(Membership_ID VARCHAR(12) NOT NULL CONSTRAINT MEMBERSHIP_pk PRIMARY KEY,
Customer_No VARCHAR(12) NOT NULL CONSTRAINT MEMBERSHIP_Customer_No_fk
REFERENCES  CUSTOMER(Customer_No)  ,
Member_Name VARCHAR(50) NOT NULL,
Member_Gender VARCHAR(6) NOT NULL,
Member_PhoneNo VARCHAR(15) NOT NULL,
Member_Address VARCHAR(255) NOT NULL,
Member_DOB DATE NOT NULL,
Register_Date DATE NOT NULL
);

INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M09980', 'CA9496' , 'Farah' , 'Female', '014-3333222' ,'98,Jalan Ipoh 9,Taman Ipoh,30100, Ipoh,Perak ', (to_date('28/8/1998','dd/mm/yyyy')), (to_date('29/12/2020','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M19200', 'CB8480' , 'J.W.W.Birch' , 'Male', '016-9999888' ,'82, Jalan Aman Larkin 12,Taman Larkin,28000 Aman Larkin,Johor', (to_date('01/08/2000','dd/mm/yyyy')) , (to_date('09/07/2000','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M10190', 'CA1080' , 'Jacky Chan' , 'Male', '018-1111222' ,'20,Tingkat Kledang 12,Taman Kledang,31450 Menglembu,Perak', (to_date('16/05/1996','dd/mm/yyyy')) ,(to_date('01/01/2021','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M10189', 'CC4200' , 'Muhammad Ali' , 'Male', '016-2222555' , '29, Jalan Sungai, Taman Suria, 75000, Malacca, Melaka' ,(to_date('08/08/1988','dd/mm/yyyy')) , (to_date('01-01-2021','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M17890', 'CC8110' , 'Lee Zhong Wei' , 'Male', '011-4444555' , '29,Bukit Kledang 9,Taman Menglembu,31450,Menglembu,Perak' ,(to_date('01/04/1980','dd/mm/yyyy')), (to_date('06-05-2021','dd/mm/yyyy'))
);





ALTER TABLE SALES
ADD CONSTRAINT SALES_Customer_No_fk
FOREIGN KEY (Customer_No) REFERENCES CUSTOMER(Customer_No);

ALTER TABLE CUSTOMER
ADD CONSTRAINT CUSTOMER_Membership_ID_fk
FOREIGN KEY (Membership_ID) REFERENCES MEMBERSHIP( Membership_ID);

ALTER TABLE CUSTOMER
ADD CONSTRAINT CUSTOMER_Sales_ID_fk
FOREIGN KEY (Sales_ID) REFERENCES SALES( Sales_ID);






CREATE TABLE BOOK_SALES
(Book_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_SALES_Book_ID_fk REFERENCES  BOOK (Book_ID),
Sales_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_SALES_Sales_ID_fk REFERENCES  SALES(Sales_ID),
CONSTRAINT BOOK_SALES_pk PRIMARY KEY ( Book_ID, Sales_ID),
Book_Name VARCHAR(255) NOT NULL
);

INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0010' , '"Learn How To Cook Easy"' , 'SS12400'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0190' , '"How To Success"' , 'SS10000'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0100' , '"Harry Potter"' , 'SS10000'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B1050' , '"Grammar in 30 days"' , 'SS10999'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0300' , '"Doraemon"' , 'SS10999'
);
CREATE TABLE YOUNG_ADULTS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT YOUNG_ADULTS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B1050', 'Education Categories', '"Grammar in 30 days"', 'J.W.W.Birch', 2019
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES('B8990', 'Education Categories',  '"Learning Japanese"', 'Jacky Chan', 2018
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B9010', 'Novel Categories', '“Little Women”', 'Louisa May Alcott', 2000
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B9012','Novel Categories', '“Anne of Green Gables”', 'L. M. Montgomery', 1998
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B9178', 'Novel Categories', '“A Tree Grows in Brooklyn”', 'Betty Smith',1999
);


CREATE TABLE ADULTS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT ADULTS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);

INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B0010','Cooking Teaching Categories', '“Learn How To Cook Easy”', 'ABU CHAN', 2008
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B0190', 'Business Categories', '“How to success”', 'JACK MA', 2015
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B2990', 'Business Categories', '“How Company Run”', 'JACK MA', 2018
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B7691', 'Novel Categories', '“The Library of Lost Things”', 'Laura Taylor Namey',2015
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B7899', 'Eduacation Categories', '“Teach you how to be a pro camera man”', 'Cindy Wo',2020
);
CREATE TABLE TEENAGERS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT TEENAGERS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);

INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B0100', 'Novel Categories', '“Harry Potter”', 'J. Wan', 1998
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B2200', 'Novel Categories', '“One of Us is Lying',  '“Wan.Dong', 2018
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B3200', 'Eduacation Categories', '“How to be a great person”','Cindy QQ', 2019
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B4900', 'Novel Categories', '“The Hate You give”', 'Wan.Dong', 2020
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B8915', 'Comic Categories' , '“Avenger of Ali”', 'Cai Xu Kun',2017
);


CREATE TABLE KIDS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT KIDS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
); 

INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B0300','Comic Categories','“Doraemon”','F.SOMEWHO',2002
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B1200', 'Comic Categories', '“ Upin dan Ipin”','Mohammad Ali',2002
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B4200', 'Comic Categories','“ Captain marvel”', 'John Cena',2017
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B7800', 'Comic Categories', '“Superman”', 'Emily Henry', 2019
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B9011', 'Eduacation Categories', '“Study A~Z”','Jochelle Lang',2021
);
CREATE TABLE NEW_CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT NEW_CUSTOMER_pk PRIMARY KEY,	
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15),
Customer_DOB DATE
);

INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0019', 'Chong Yew Cho', '014-37773330', (to_date('01/08/2000','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ('CD0020', 'John Wong', '019-5435432', (to_date('04/01/2000','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0021', 'Frankie An', '011-3456781',	(to_date('30/12/1992','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0022', 'Fikri Muhammad Ali', '016-1234555',(to_date('07/08/1989','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CD0023', 'Chan Ma Ma', '018-8877111',(to_date('12/09/2005','dd/mm/yyyy'))
);


CREATE TABLE  EXISTING_CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT EXISTING_CUSTOMER_pk PRIMARY KEY,	
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15),
Customer_DOB DATE
);

INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CA1080', 'Jacky Chan', '018-1111222', (to_date('12/08/2000','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CC4200', 'Muhammad Ali', '016-2222555',(to_date('08/08/1988','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CC8110','Lee Zhong Wei', '011-4444555',(to_date('01/04/1980','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CB8480', 'J.W.W.Birch', '016-9999888',(to_date('20/02/1999','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CA9496', 'Farah', '014-3333222', (to_date('28/08/1998','dd/mm/yyyy'))
);


set linesize 800


SELECT  staff.staff_ID,staff.staff_Name,branch.branch_state as Working_State
FROM staff
LEFT JOIN branch
ON staff.branch_id = branch.branch_id
ORDER BY staff.staff_ID;  

 
SELECT membership_id,member_name,register_date, 
add_months( to_date(register_date), 12 ) 
AS expired_date FROM membership;


SELECT  sales.sales_date, customer.customer_name,branch.branch_name,branch_state
FROM sales
JOIN customer
ON sales.customer_no = customer.customer_no
JOIN branch
ON sales.branch_id = branch.branch_id;

  
SELECT  sales.sales_id, customer.customer_name,staff.staff_name
FROM sales
JOIN customer
ON sales.customer_no = customer.customer_no
JOIN staff
ON sales.staff_id = staff.staff_id;


SELECT COUNT(sales.sales_id) AS total_sales_bill,
AVG(round(months_between(sysdate, membership.member_dob) / 12)) AS average_age_of_customer,
AVG(sales.sales_amount_unitRM) AS average_payment_unitRM
FROM membership
JOIN sales
ON membership.customer_no = sales.customer_no;

 
SELECT inventory.inv_id, branch.branch_name, branch.branch_state
FROM inventory
JOIN branch
on inventory.branch_id = branch.branch_id;


SELECT STAFF_NAME, STAFF_IC, STAFF_DOB,
TRUNC(TO_NUMBER(SYSDATE - TO_DATE(Staff_DOB)) / 365.25) 
AS AGE FROM STAFF;


SELECT membership.member_name, membership.membership_id, COUNT(sales.sales_id) AS puchase_record_UnitCASE
FROM membership
JOIN sales
ON membership.customer_no = sales.customer_no
Group by membership.member_name, membership.membership_id;


SELECT branch.branch_name,customer.customer_name,sales.sales_amount_unitRm
FROM branch
JOIN customer
ON branch.branch_id = customer.branch_id
RIGHT JOIN sales
on customer.branch_id = sales.branch_id
WHERE sales.sales_amount_unitRm 
IN 
(SELECT DISTINCT MAX(sales_amount_unitRm) FROM sales);



SELECT SUM(sales_amount_unitRM) as total_sales_of_company_unitRM
FROM sales;


CREATE OR REPLACE PROCEDURE delete_staff ( 
Delete_ID varchar )
AS BEGIN  
DELETE FROM staff
WHERE staff_id = Delete_ID;
END;
/


CREATE OR REPLACE PROCEDURE update_inventory_booknum
(
update_inv_id in varchar2,
update_inv_quantity in int
)
is
begin
UPDATE inventory
SET inv_quantity = update_inv_quantity
where inv_id = update_inv_id;
end;
/


CREATE OR REPLACE PROCEDURE insert_staff(
new_staff_id  staff.staff_id%TYPE,
new_branch_id  staff.branch_id%TYPE,
new_staff_name  staff.staff_name%TYPE,
new_staff_ic  staff.staff_ic%TYPE,
new_staff_gender  staff.staff_gender%TYPE,
new_staff_phoneno  staff.staff_phoneno%TYPE,
new_staff_address  staff.staff_address%TYPE,
new_staff_dob  staff.staff_dob%TYPE,
new_sales_performance_unitcase  staff.sales_performance_unitcase%TYPE)
IS
BEGIN 
INSERT INTO STAFF ( staff_id ,branch_id, staff_name, staff_ic, staff_gender, staff_phoneno, staff_address, staff_dob,sales_performance_unitcase)
VALUES(new_staff_id ,new_branch_id, new_staff_name, new_staff_ic, new_staff_gender, new_staff_phoneno, new_staff_address, new_staff_dob,new_sales_performance_unitcase);
COMMIT;
END;
/


CREATE OR REPLACE PROCEDURE printStaff(
s_id IN STAFF.staff_id%TYPE
)
IS
s_staff staff%ROWTYPE;
BEGIN
SELECT*
INTO s_staff
FROM
staff
WHERE staff_id = s_id;
dbms_output.put_line( 'STAFF NAME: ' || s_staff.staff_name || ' IC: ' || s_staff.staff_ic || ' has perform ' || s_staff.sales_performance_unitcase || ' case sales in our company.' );
END;
/


CREATE OR REPLACE PROCEDURE update_kidsbook
(
update_book_id in kids_books.book_id%TYPE,
update_book_category in kids_books.book_category%TYPE,
update_book_name in kids_books.book_name%TYPE,
update_book_author in kids_books.book_author%TYPE,
update_book_publishdate in kids_books.book_publishdate%TYPE
)
is
begin
UPDATE kids_books
SET 
Book_Category  = update_book_category,
book_name = update_book_name,
Book_author  = update_book_author,
Book_publishdate = update_book_publishdate
where book_id = update_book_id ;
end;
/



CREATE OR REPLACE FUNCTION commission_RM
(s_id IN staff.staff_id%TYPE)
RETURN NUMBER
IS 
commission NUMBER;
BEGIN
SELECT sales_performance_unitcase
INTO commission 
FROM staff WHERE staff_id = s_id;
commission := commission * 1.5;
RETURN commission;
END;
/


CREATE OR REPLACE FUNCTION total_member
RETURN NUMBER
IS
TOTAL NUMBER;
BEGIN
SELECT COUNT(*) 
INTO total
FROM membership;
RETURN TOTAL;
END;
/


CREATE OR REPLACE FUNCTION find_age(
m_id IN membership.membership_id%TYPE
)
RETURN NUMBER
IS
Age NUMBER;
BEGIN
SELECT round(months_between(sysdate, member_dob) / 12)
INTO Age
FROM membership
WHERE
membership_id = m_id;
RETURN AGE;
END;
/

CREATE OR REPLACE FUNCTION freegift(c_no in customer.customer_no%TYPE)
RETURN VARCHAR
IS BEGIN
IF c_no = 'CA1080'
THEN
RETURN 'is 1080th customer, verified to earn free gift';
ELSE
RETURN 'Not verified to get free gift';
END IF;
END;
/


CREATE OR REPLACE FUNCTION findperak
(m_address IN membership.member_address%TYPE)
RETURN VARCHAR
IS 
BEGIN
IF
m_address LIKE '%Perak%'
THEN 
RETURN ' LIVING AT PERAK ';
ELSE
RETURN ' NOT LIVE IN PERAK  ';
END IF;
END; 
/




