CREATE TABLE BRANCH
(Branch_ID VARCHAR(5) NOT NULL CONSTRAINT BRANCH_pk PRIMARY KEY,
Branch_Name VARCHAR(50) NOT NULL,	
Branch_State VARCHAR(50) NOT NULL,
Branch_Customer_Quantity INT
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B01','WISDOM Book Store Menglembu','Perak','190899'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B02','WISDOM Book Store Simpang Ampat','Selangor','120998'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B03','WISDOM Book Store Ipoh Parade','Perak','70222'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B04','WISDOM Book Store Malcca','Melaka','60888'
);
INSERT INTO BRANCH 
(Branch_ID,Branch_Name,Branch_State,Branch_Customer_Quantity) 
VALUES ('B05','WISDOM Book Store Aman Larkin','Johor','40233'
);

CREATE TABLE STAFF
( Staff_ID  VARCHAR(12) NOT NULL CONSTRAINT STAFF_pk PRIMARY KEY ,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT Staff_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID) ,
Staff_Name VARCHAR(50) NOT NULL ,
Staff_IC VARCHAR(12) NOT NULL ,
Staff_Gender VARCHAR(6) NOT NULL,	
Staff_PhoneNo VARCHAR(15) NOT NULL,	
Staff_Address VARCHAR(255),	
Staff_DOB DATE ,
Sales_Performance_UnitCase INT
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '101', 'Andrew Boh Zhuang Wei', '000202085547', 'Male', '018-2342345', '10,Jalan Utar 11,Taman Utar,30500,Ipoh,Perak', (to_date('02/02/2000','dd/mm/yyyy')), 'B01', 650
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '102', 'Chong Khai Siang', '990929086647', 'Male', '018-5675678', '27, Tingkat Kledang7,Taman Kledang,31450,Menglembu,Perak', (to_date('29/09/1999','dd/mm/yyyy')), 'B01', 420
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '103', 'Chung Jun Jie Alvin','010828087747', 'Male', '012-8908901', '95,Jalan Merah 8,Taman Merah, 14100, Simpang Ampat, Selangor', (to_date('28/08/2001','dd/mm/yyyy')), 'B02', 300
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '104', 'Loh Chun Yi', '011201088847', 'Male', '012-1231234' ,'3, Jalan Sungai, Taman Suria, 75000, Malacca, Melaka', (to_date('01/12/2001','dd/mm/yyyy')), 'B04', 900
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '105', 'Wong Jian Yong', '010420089947', 'Male' , '011-4564562', '8, Tingkat Kledang 8,Taman Kledang, 31450, Menglembu,Perak', (to_date('20/04/2001','dd/mm/yyyy')), 'B03', 700
);
INSERT INTO STAFF
(Staff_ID, Staff_Name, Staff_IC, Staff_Gender, Staff_PhoneNo, Staff_Address, Staff_DOB, Branch_ID, Sales_Performance_UnitCase)
VALUES ( '109', 'Obama', '990808065547', 'Male', '018-5477123', '12, Jalan Aman Larkin 2, Taman Larkin, 28000 Aman Larkin,Johor', (to_date('08/08/1999','dd/mm/yyyy')), 'B05', 200
);



CREATE TABLE INVENTORY
(Inv_ID VARCHAR(12) NOT NULL CONSTRAINT INVENTORY_pk PRIMARY KEY,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT INVENTORY_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID)  ,
Inv_Quantity INT
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L001' , '2000' , 'B01'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L002' , '2000' , 'B01'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L003' , '3500' , 'B02'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L004' , '2000' , 'B03'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L006' , '2000' , 'B04'
);
INSERT INTO INVENTORY
(Inv_ID, Inv_Quantity , Branch_ID)
VALUES ('L007' , '1500' , 'B05'
);



CREATE TABLE BOOK
(Book_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_pk PRIMARY KEY,
Inv_ID	 VARCHAR (12) NOT NULL CONSTRAINT BOOK_Inv_ID_fk
REFERENCES  INVENTORY(Inv_ID),
Book_Type VARCHAR(255) NOT NULL,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Price_UnitRM NUMBER
); 
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0010','L006','Adult','Cooking Teaching Categories','"Learn How To Cook Easy"',15
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0190','L001','Adult','Business Categories','"How To Success"',50
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0300','L007','Kids','Comic Categories','"Doraemon"', 15
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B0100','L002','Teenager','Novel Categories','”Harry Potter”',30
);
INSERT INTO BOOK (Book_ID,Inv_ID,Book_Type,Book_Category,Book_Name,Book_Price_UnitRM) 
VALUES('B1050', 'L007', 'Young Adult', 'Education Categories', '“Grammar in 30 days”',23 
);
CREATE TABLE SALES
(Sales_ID VARCHAR(12) NOT NULL CONSTRAINT SALES_pk PRIMARY KEY ,
Staff_ID VARCHAR(12) NOT NULL CONSTRAINT SALES_Staff_ID_fk
REFERENCES  Staff(Staff_ID),
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT SALES_Branch_ID_fk REFERENCES  BRANCH(Branch_ID),
Customer_No VARCHAR(12) NOT NULL,
Sales_Amount_UnitRM NUMBER NOT NULL,
Book_Quantity INT NOT NULL,
Sales_Date Date 
);

INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS10000' , (to_date('09/07/2021','dd/mm/yyyy')) , 80 , '101' , 'CC8110' , 6 , 'B01' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS09800' , (to_date('08/07/2021','dd/mm/yyyy')) , 120 , '102' , 'CA1080' , 8, 'B02' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS12400' , (to_date('10/07/2021','dd/mm/yyyy')) , 15 , '104' , 'CC4200' , 1 , 'B04' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS12000' , (to_date('10/07/2021','dd/mm/yyyy')) , 9, '101' , 'CA9496' , 1 , 'B03' 
);
INSERT INTO SALES
(Sales_ID, Sales_Date,Sales_Amount_UnitRM,Staff_ID,Customer_No,Book_Quantity,Branch_ID) 
VALUES( 'SS10999' , (to_date('09/07/2021','dd/mm/yyyy')) , 38 , '109' , 'CB8480' , 2 , 'B05' 
);

CREATE TABLE CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT CUSTOMER_pk PRIMARY KEY,
Branch_ID VARCHAR(5) NOT NULL CONSTRAINT Customer_Branch_ID_fk
REFERENCES  BRANCH(Branch_ID)  ,	
Sales_ID VARCHAR(12) NOT NULL ,
Membership_ID VARCHAR(12),
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15)
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CA1080' , 'SS09800' , 'M10190' , 'B02' , 'Jacky Chan' , ' 018-1111222' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CC4200' , 'SS12400' , 'M10189' , 'B04' , 'Muhammad Ali'  , '016-2222555' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CC8110' , 'SS10000' , 'M17890' , 'B01' , 'Lee Zhong Wei' , ' 011-4444555' 
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CB8480' , 'SS10999' , 'M19200' , 'B05' , 'J.W.W.Birch' , ' 016-9999888'
);
INSERT INTO CUSTOMER
(Customer_No , Sales_ID , Membership_ID ,Branch_ID, Customer_Name, Customer_PhoneNo)
VALUES ('CA9496' , 'SS12000' , 'M09980' , 'B03' , 'Farah' , '014-3333222'
);

CREATE TABLE MEMBERSHIP 
(Membership_ID VARCHAR(12) NOT NULL CONSTRAINT MEMBERSHIP_pk PRIMARY KEY,
Customer_No VARCHAR(12) NOT NULL CONSTRAINT MEMBERSHIP_Customer_No_fk
REFERENCES  CUSTOMER(Customer_No)  ,
Member_Name VARCHAR(50) NOT NULL,
Member_Gender VARCHAR(6) NOT NULL,
Member_PhoneNo VARCHAR(15) NOT NULL,
Member_Address VARCHAR(255) NOT NULL,
Member_DOB DATE NOT NULL,
Register_Date DATE NOT NULL
);

INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M09980', 'CA9496' , 'Farah' , 'Female', '014-3333222' ,'98,Jalan Ipoh 9,Taman Ipoh,30100, Ipoh,Perak ', (to_date('28/8/1998','dd/mm/yyyy')), (to_date('29/12/2020','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M19200', 'CB8480' , 'J.W.W.Birch' , 'Male', '016-9999888' ,'82, Jalan Aman Larkin 12,Taman Larkin,28000 Aman Larkin,Johor', (to_date('01/08/2000','dd/mm/yyyy')) , (to_date('09/07/2000','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M10190', 'CA1080' , 'Jacky Chan' , 'Male', '018-1111222' ,'20,Tingkat Kledang 12,Taman Kledang,31450 Menglembu,Perak', (to_date('16/05/1996','dd/mm/yyyy')) ,(to_date('01/01/2021','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M10189', 'CC4200' , 'Muhammad Ali' , 'Male', '016-2222555' , '29, Jalan Sungai, Taman Suria, 75000, Malacca, Melaka' ,(to_date('08/08/1988','dd/mm/yyyy')) , (to_date('01-01-2021','dd/mm/yyyy'))
);
INSERT INTO MEMBERSHIP (Membership_ID,Customer_No,Member_name,member_gender,Member_phoneno,Member_address,Member_DOB,Register_Date)
VALUES ('M17890', 'CC8110' , 'Lee Zhong Wei' , 'Male', '011-4444555' , '29,Bukit Kledang 9,Taman Menglembu,31450,Menglembu,Perak' ,(to_date('01/04/1980','dd/mm/yyyy')), (to_date('06-05-2021','dd/mm/yyyy'))
);





ALTER TABLE SALES
ADD CONSTRAINT SALES_Customer_No_fk
FOREIGN KEY (Customer_No) REFERENCES CUSTOMER(Customer_No);

ALTER TABLE CUSTOMER
ADD CONSTRAINT CUSTOMER_Membership_ID_fk
FOREIGN KEY (Membership_ID) REFERENCES MEMBERSHIP( Membership_ID);

ALTER TABLE CUSTOMER
ADD CONSTRAINT CUSTOMER_Sales_ID_fk
FOREIGN KEY (Sales_ID) REFERENCES SALES( Sales_ID);






CREATE TABLE BOOK_SALES
(Book_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_SALES_Book_ID_fk REFERENCES  BOOK (Book_ID),
Sales_ID VARCHAR(12) NOT NULL CONSTRAINT BOOK_SALES_Sales_ID_fk REFERENCES  SALES(Sales_ID),
CONSTRAINT BOOK_SALES_pk PRIMARY KEY ( Book_ID, Sales_ID),
Book_Name VARCHAR(255) NOT NULL
);

INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0010' , '"Learn How To Cook Easy"' , 'SS12400'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0190' , '"How To Success"' , 'SS10000'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0100' , '"Harry Potter"' , 'SS10000'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B1050' , '"Grammar in 30 days"' , 'SS10999'
);
INSERT INTO BOOK_SALES 
(Book_ID , Book_Name , Sales_ID )
VALUES('B0300' , '"Doraemon"' , 'SS10999'
);
CREATE TABLE YOUNG_ADULTS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT YOUNG_ADULTS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B1050', 'Education Categories', '"Grammar in 30 days"', 'J.W.W.Birch', 2019
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES('B8990', 'Education Categories',  '"Learning Japanese"', 'Jacky Chan', 2018
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B9010', 'Novel Categories', '“Little Women”', 'Louisa May Alcott', 2000
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B9012','Novel Categories', '“Anne of Green Gables”', 'L. M. Montgomery', 1998
);
INSERT INTO YOUNG_ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B9178', 'Novel Categories', '“A Tree Grows in Brooklyn”', 'Betty Smith',1999
);


CREATE TABLE ADULTS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT ADULTS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);

INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B0010','Cooking Teaching Categories', '“Learn How To Cook Easy”', 'ABU CHAN', 2008
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B0190', 'Business Categories', '“How to success”', 'JACK MA', 2015
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B2990', 'Business Categories', '“How Company Run”', 'JACK MA', 2018
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B7691', 'Novel Categories', '“The Library of Lost Things”', 'Laura Taylor Namey',2015
);
INSERT INTO ADULTS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B7899', 'Eduacation Categories', '“Teach you how to be a pro camera man”', 'Cindy Wo',2020
);
CREATE TABLE TEENAGERS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT TEENAGERS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
);

INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B0100', 'Novel Categories', '“Harry Potter”', 'J. Wan', 1998
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B2200', 'Novel Categories', '“One of Us is Lying',  '“Wan.Dong', 2018
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B3200', 'Eduacation Categories', '“How to be a great person”','Cindy QQ', 2019
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B4900', 'Novel Categories', '“The Hate You give”', 'Wan.Dong', 2020
);
INSERT INTO TEENAGERS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B8915', 'Comic Categories' , '“Avenger of Ali”', 'Cai Xu Kun',2017
);


CREATE TABLE KIDS_BOOKS
(Book_ID  VARCHAR(12) NOT NULL CONSTRAINT KIDS_BOOKS_pk PRIMARY KEY,
Book_Category VARCHAR(255) NOT NULL,
Book_Name VARCHAR(255) NOT NULL,
Book_Author VARCHAR(255) NOT NULL,
Book_PublishDate INT NOT NULL
); 

INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B0300','Comic Categories','“Doraemon”','F.SOMEWHO',2002
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B1200', 'Comic Categories', '“ Upin dan Ipin”','Mohammad Ali',2002
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B4200', 'Comic Categories','“ Captain marvel”', 'John Cena',2017
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ('B7800', 'Comic Categories', '“Superman”', 'Emily Henry', 2019
);
INSERT INTO KIDS_BOOKS
(Book_ID,Book_Category,Book_Name,Book_Author,Book_PublishDate)
VALUES ( 'B9011', 'Eduacation Categories', '“Study A~Z”','Jochelle Lang',2021
);
CREATE TABLE NEW_CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT NEW_CUSTOMER_pk PRIMARY KEY,	
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15),
Customer_DOB DATE
);

INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0019', 'Chong Yew Cho', '014-37773330', (to_date('01/08/2000','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ('CD0020', 'John Wong', '019-5435432', (to_date('04/01/2000','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0021', 'Frankie An', '011-3456781',	(to_date('30/12/1992','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES ( 'CD0022', 'Fikri Muhammad Ali', '016-1234555',(to_date('07/08/1989','dd/mm/yyyy'))
);
INSERT INTO NEW_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CD0023', 'Chan Ma Ma', '018-8877111',(to_date('12/09/2005','dd/mm/yyyy'))
);


CREATE TABLE  EXISTING_CUSTOMER
(Customer_No VARCHAR(12) NOT NULL CONSTRAINT EXISTING_CUSTOMER_pk PRIMARY KEY,	
Customer_Name VARCHAR(50) NOT NULL,
Customer_PhoneNo VARCHAR(15),
Customer_DOB DATE
);

INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CA1080', 'Jacky Chan', '018-1111222', (to_date('12/08/2000','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CC4200', 'Muhammad Ali', '016-2222555',(to_date('08/08/1988','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CC8110','Lee Zhong Wei', '011-4444555',(to_date('01/04/1980','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CB8480', 'J.W.W.Birch', '016-9999888',(to_date('20/02/1999','dd/mm/yyyy'))
);
INSERT INTO EXISTING_CUSTOMER 
(Customer_No, Customer_Name, Customer_PhoneNo, Customer_DOB )
VALUES (  'CA9496', 'Farah', '014-3333222', (to_date('28/08/1998','dd/mm/yyyy'))
);

Select Book_Name, Book_ID, Book_Price_UnitRM
from BOOK
where Book_Price_UnitRM > 15;

Select B.Book_Name, I.Inv_Quantity 
from Book B, INVENTORY I
Where I.Inv_ID = B.Inv_ID;

Select C.Customer_Name, c.Customer_PhoneNo, S.Book_Quantity, B.Branch_Name
From Customer C, Sales S, Branch B
Where C.Customer_No = S.Customer_No
and B.Branch_ID = C.Branch_ID;

Select Staff_Name, Staff_PhoneNo, Sales_Performance_UnitCase
From Staff 
Order By Sales_Performance_UnitCase DESC;

Select S.Staff_Name, S.Staff_IC, B.Branch_Name, B.Branch_State
From Staff S, Branch B
Where S.Branch_ID = B.Branch_ID;

Select membership_id, member_name, member_gender
from membership;

select c.customer_name, m.membership_id, m.member_address, m.register_date
from customer c, membership m
where c.membership_id = m.membership_id
and m.member_address like '%Perak%';

select c.customer_name, m.membership_id, m.register_date
from customer c, membership m
where c.membership_id = m.membership_id
and m.register_date = '06-MAY-21';

select c.customer_name, m.membership_id, m.member_phoneNO
from customer c, membership m
where c.membership_id = m.membership_id;

select branch_id, branch_name, branch_state 
From Branch
Where branch_state = 'Selangor' 
OR branch_state = 'Johor' ; 

CREATE OR REPLACE PROCEDURE update_Sales_Quantity
(
update_Sales_ID in varchar2,
update_Sales_Amount_UnitRM in int
)
is 
BEGIN
UPDATE Sales
SET Sales_Amount_UnitRM = update_Sales_Amount_UnitRM
where Sales_ID = update_Sales_ID;
END;
/




CREATE OR REPLACE PROCEDURE new_sales
(
new_SALES_ID varchar2,
new_STAFF_ID int,
new_BRANCH_ID varchar2,
new_CUSTOMER_NO varchar2,
new_SALES_AMOUNT_UNITRM int,
new_BOOK_QUANTITY int,
new_SALES_DATE date
)
AS 
BEGIN
insert into sales(SALES_ID, STAFF_ID, BRANCH_ID, CUSTOMER_NO, SALES_AMOUNT_UNITRM, BOOK_QUANTITY, SALES_DATE)
VALUES (new_SALES_ID, new_STAFF_ID, new_BRANCH_ID, new_CUSTOMER_NO, new_SALES_AMOUNT_UNITRM, new_BOOK_QUANTITY, new_SALES_DATE);
END;
/



CREATE OR REPLACE PROCEDURE EDIT_customer_Quantity
(
update_BRANCH_ID in varchar2,
update_CUSTOMER_QUANTITY in int
)
is 
BEGIN
UPDATE BRANCH
SET BRANCH_CUSTOMER_QUANTITY = update_CUSTOMER_QUANTITY
where BRANCH_ID = update_BRANCH_ID;
END;
/


CREATE OR REPLACE PROCEDURE del_book
(
del_BOOK_ID varchar2,
del_INV_ID varchar2,
del_BOOK_TYPE varchar2,
del_BOOK_CATEGORY varchar2,
del_BOOK_NAME varchar2,
del_BOOK_PRICE_UNITRM int
)
AS
BEGIN
DELETE FROM Book
WHERE BOOK_ID = del_BOOK_ID
AND INV_ID = del_INV_ID
AND BOOK_TYPE = del_BOOK_TYPE
AND BOOK_CATEGORY = del_BOOK_CATEGORY
AND BOOK_NAME = del_BOOK_NAME
AND BOOK_PRICE_UNITRM = del_BOOK_PRICE_UNITRM;
END;
/


CREATE OR REPLACE PROCEDURE add_membership
(
new_membership_id varchar2,
new_customer_no varchar2,
new_member_name varchar2,
new_member_gender varchar2,
new_member_phoneno varchar2,
new_member_address varchar2,
new_member_dob date,
new_register_date date
)
as
begin
insert into membership(membership_id, customer_no, member_name, member_gender, member_phoneno, member_address, member_DOB, register_date )
values (new_membership_id, new_customer_no, new_member_name, new_member_gender, new_member_phoneno, new_member_address, new_member_dob, new_register_date);
end;
/



CREATE OR REPLACE FUNCTION mem_gender
( m_gender_Unitcase IN VARCHAR2)
RETURN VARCHAR2
IS
BEGIN
IF m_gender_Unitcase = 'Female'
THEN
RETURN 'Congrats, You received a reward!!!';
ELSE
RETURN 'No reward given!!!';
END IF;
END;
/



CREATE OR REPLACE FUNCTION q_sales
( quan_sales_Unitcase IN INT)
RETURN VARCHAR2
IS
BEGIN
IF quan_sales_Unitcase >= '400'
THEN
RETURN 'Well done, keep going for the future!!!';
ELSE
RETURN 'Try harder, you can do it!!!';
END IF;
END;
/ 




CREATE OR REPLACE FUNCTION branch_status
( b_status_Unitcase IN VARCHAR2)
RETURN VARCHAR2
IS
BEGIN
IF b_status_Unitcase = 'Selangor' || 'Johor' || 'Melaka'
THEN
RETURN 'Branch is closed, wait for future announcment...';
ELSE 
RETURN 'Work is on going, you may go for work...';
END IF;
END;
/ 




create or replace function cal_total_sales
(sales_amount_unitRM in varchar2)
return number
is 
total_sales number;
begin
select sum(sales_amount_unitRM) into total_sales from sales;
Return total_sales;
end;
/



CREATE OR REPLACE FUNCTION inv_left
( i_left_Unitcase IN int)
RETURN varchar2
IS
BEGIN
IF i_left_Unitcase <= '2500'
THEN
RETURN 'Opps, inventory is not enough for next month...';
ELSE
RETURN 'inventory is enough for next month...';
END IF;
END;
/


















